from polls.models import Textz

Textz(text_head="sss",text_jianjie="aiuwgdbjk",text_user="kon",text_tt="agaggduihqehfjjkfuajkhjkawhdioah")