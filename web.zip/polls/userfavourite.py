from polls.models import Textz,Unfavourable
def user_favourite(id):
    if len(Textz.objects.filter(text_id=id)) == 0:
        return None
    text = Textz.objects.get(text_id=id)
    return text

def my_favourite_DAO(id):
    if len(Unfavourable.objects.filter(user_id=id)) ==0:
        return False
    user = Unfavourable.objects.get(user_id=id)
    return user
