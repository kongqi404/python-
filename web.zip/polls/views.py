from datetime import datetime
from django.http import HttpResponse
from polls.inform import index_inform, entry_inform

from django.shortcuts import render
from django.utils.safestring import mark_safe

from polls.models import Textz
from polls.userfavourite import user_favourite,my_favourite_DAO


def user_favourite_add(request):
    if request.method == "POST":
        if "id" in request.POST:
            fav = user_favourite(int(request.POST["id"]))

            if "is_ed"in request.session or fav is None:
                return HttpResponse(-1)


            fav.text_favourite +=1
            fav.save()
            rep = HttpResponse()
            request.session["is_ed"]=True
            request.session.set_expiry(60*60*24)
            rep.write(str(fav.text_favourite))
            return rep
        if "my_id" in request.POST:
            myfav=my_favourite_DAO(int(request.POST["my_id"]))
            if myfav is None:
                return HttpResponse(-1)
            myfav.favourite+=1
            myfav.save()
            rep=HttpResponse()
            rep.write(str(myfav.favourite))
            return rep





def index(request):
    my_favourite = my_favourite_DAO(1)
    dict_inform=index_inform()
    dict_inform["my_favourite"]=my_favourite.favourite
    return render(request, "index.html",dict_inform)


def about(request):
    return render(request, "about.html")


def entry(request):
    dict_entry = entry_inform(int(request.GET["id"]))
    if dict_entry is None:
        return HttpResponse(status=404)
    return render(request, "entry.html", dict_entry)


def message(request):
    return render(request, "message.html")


def text_list(request):
    return render(request, "text_list.html")
