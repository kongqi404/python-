from datetime import datetime

from django.http import HttpResponse

from polls.models import Textz
from django.shortcuts import render
from django.utils.safestring import mark_safe


def add(request):
    if request.method == "POST":
        if "favourite" in request.POST and "id" in request.POST:
            if len(Textz.objects.filter(text_id=int(request.POST["id"]))) != 0 and "is_ed" not in request.COOKIES:
                test1 = Textz.objects.get(text_id=int(request.POST["id"]))
                test1.text_favourite += 1
                test1.save()
                rep = HttpResponse()
                rep.set_signed_cookie("is_ed", "true", salt="azhe", max_age=60 * 60 * 24)
                rep.write(str(test1.text_favourite))
                return rep
            else:
                return HttpResponse(-1)


def index(request):
    return render(request, "index.html", {"my_favourite": 1})


def about(request):
    return render(request, "about.html")


def entry(request):
    a = Textz.objects.get(text_id=3)
    text = mark_safe("<p>azhe</p><p>safga</p>")
    return render(request, "entry.html", {"favorites": a.text_favourite,
                                          "writer_name": a.text_user,
                                          "date": datetime.today().day - a.text_date.day,
                                          "text_head": a.text_head,
                                          "text": text})


def message(request):
    return render(request, "message.html")


def text_list(request):
    return render(request, "text_list.html")
