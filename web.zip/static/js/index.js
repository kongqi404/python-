
function index_add_button() {
    location.href="http://127.0.0.1:8000/entry.html"
}
function goto_Twitter() {
    open("https://twitter.com/GBe4yGzTAdE0xjb")

}
function goto_Facebook() {
    open("https://weibo.com/5762683437/profile?topnav=1&wvr=6&is_all=1")

}

